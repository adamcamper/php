<?php

define('DB_SERVER', "localhost");
define('DB_USERNAME', "webauth");
define('DB_PASSWORD', "webauth");
define('DB_DATABASE', "sucram");

$conn = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

if(!$conn){
    die("connection failed: ". mysqli_connect_error());
}


?>
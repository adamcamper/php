<?php
session_start();

require 'dbcon.php';

function validate($inputData){

    global $conn;

    return mysqli_real_escape_string($conn, $inputData);


}

function getAll($tableName){
 
    global $conn;

    $table = validate($tableName);

    $query = "SELECT * FROM $table";
    $result = mysqli_query($conn, $query);
    return $result;


}

?>
<?php require '../config/dbcon.php'; ?>

<?php

$filename = "jason_data.json";
$json_data = file_get_contents($filename);
$data_arr = json_decode(json_data, true);

foreach($data_arr as $row){
    $name = $row['cc_num'];
    $name = $row['cvv'];
    $name = $row['first_name'];
    $name = $row['surname'];
    $name = $row['address'];
    $name = $row['post_code'];
    $name = $row['country'];
    $name = $row['phone'];
    $name = $row['email'];
    $name = $row['exp_date'];

    $sql = "insert into orders (cc_num,cvv,first_name,surname,address,post_code,country,phone,email,exp_date) values(?,?,?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);

    

}



?>
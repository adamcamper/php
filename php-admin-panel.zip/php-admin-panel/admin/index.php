<?php include('includes/header.php'); ?>

<h4>hello my friend</h4>

<?php include('includes/footer.php'); ?>
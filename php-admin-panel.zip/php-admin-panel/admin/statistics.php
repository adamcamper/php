<?php include('includes/header.php'); ?>
<?php require '../config/function.php'; ?>

<div class="card-body">

    <table id="myTable" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>id</th>
                <th>cc num</th>
                <th>exp date</th>
                <th>cvv</th>
                <th>first name</th>
                <th>surname</th>
                <th>address</th>
                <th>post code</th>
                <th>country</th>
                <th>phone</th>
                <th>email</th>
                <th>created_at</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                $orders = getAll('orders');
                if(mysqli_num_rows($orders) > 0){
                    foreach($orders as $orderItem)
                    ?>
                    <tr>
                <td><?= $orderItem['Id']; ?></td>
                <td><?= $orderItem['cc_num']; ?></td>
                <td><?= $orderItem['exp_date']; ?></td>
                <td><?= $orderItem['cvv']; ?></td>
                <td><?= $orderItem['first_name']; ?></td>
                <td><?= $orderItem['surname']; ?></td>
                <td><?= $orderItem['address']; ?></td>
                <td><?= $orderItem['post_code']; ?></td>
                <td><?= $orderItem['country']; ?></td>
                <td><?= $orderItem['phone']; ?></td>
                <td><?= $orderItem['email']; ?></td>
                <td><?= $orderItem['created_at']; ?></td>
            </tr>
                    <?php 
                }
                else{
                    ?>
                    <tr>
                        <td colspan="12">No Record Found!</td> 
                    </tr>
                    <?php
                }
            ?>
            
        </tbody>
    </table>
</div>


                

<?php include('includes/footer.php'); ?>